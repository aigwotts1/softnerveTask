package com.softnerve.task.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.softnerve.task.model.Patient;

public interface Repository extends MongoRepository<Patient, Integer>{

	Patient findByNameAndAddress(String name, String address);

}