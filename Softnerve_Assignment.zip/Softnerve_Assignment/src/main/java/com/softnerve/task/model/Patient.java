package com.softnerve.task.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@Document(collection = "Patient")
public class Patient {
	
	@Id
	private int id;
	
	@NotBlank(message = "Invalid Name")
	private String name;
	
    @Pattern(regexp = "\\d{10}", message = "Phone number must be exactly 10 digits")
	private String contact_details;
    
    @NotBlank(message = "Invalid Address")
	private String address;
    
    @Pattern(regexp = "\\d{6}", message = "Pincode must be exactly 6 digits")
	private String pincode;
}