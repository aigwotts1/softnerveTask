package com.softnerve.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.softnerve.task.model.Patient;
import com.softnerve.task.service.Service;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Min;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/patient")
public class RestController {
	
	@Autowired
	Service service;
	
	@PostMapping("/addPatient")
	public ResponseEntity<Patient> addPatient(@Valid @RequestBody Patient patient){
		return new ResponseEntity<>(service.addPatient(patient),HttpStatus.CREATED);
	}

	@DeleteMapping("/deletePatient/{id}")
	public ResponseEntity<Void> deletePatient(@Min(1) @PathVariable int id){
		service.deletePatientById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@PutMapping("/updatePatient/{id}")
	public ResponseEntity<Patient> updatePatient(@Min(1) @PathVariable int id,@Valid @RequestBody Patient patient){
		return new ResponseEntity<>(service.updatePatient(id,patient),HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/getPatient/{id}")
	public ResponseEntity<Patient> getPatientById(@Min(1) @PathVariable int id){
		return new ResponseEntity<>(service.getPatientById(id),HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/getPatient")
	public ResponseEntity<List<Patient>> getAllPatients(){
		return new ResponseEntity<>(service.getAllPatients(),HttpStatus.ACCEPTED);
	}
}