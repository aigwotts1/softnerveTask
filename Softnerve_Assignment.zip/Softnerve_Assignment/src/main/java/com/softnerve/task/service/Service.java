package com.softnerve.task.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.softnerve.task.exception.PatientException;
import com.softnerve.task.model.Patient;
import com.softnerve.task.repository.Repository;

@org.springframework.stereotype.Service
public class Service {
	
	@Autowired
	Repository repository;
	
	public Patient addPatient(Patient patient) {
		if(repository.findById(patient.getId()).isPresent()) {
			throw new PatientException("Patient with this Id Exists!!!");
		}
		Patient oldPatient = repository.findByNameAndAddress(patient.getName(),patient.getAddress());
		if(oldPatient != null) {
			throw new PatientException("Patient Already Added!!!");
		}
		return repository.save(patient);
	}
	
	public void deletePatientById(int id) {
		if(getPatientById(id)!=null) {
			repository.deleteById(id);
		}
	}
	
	public Patient updatePatient(int id,Patient newPatient) {
		Patient oldPatient = getPatientById(id);
		if(newPatient.getId()!=oldPatient.getId()) {
			throw new PatientException("Id should be same , other values can be updated!!!");
		}
		oldPatient.setName(newPatient.getName());
		oldPatient.setContact_details(newPatient.getContact_details());
		oldPatient.setAddress(newPatient.getAddress());
		oldPatient.setPincode(newPatient.getPincode());
		return repository.save(oldPatient);
	}
	
	public Patient getPatientById(int id) {
		return repository.findById(id).orElseThrow(()-> new PatientException("No Patient with Such Id Found!!!"));
	}
	
	public List<Patient> getAllPatients(){
		return repository.findAll();
	}
	
}